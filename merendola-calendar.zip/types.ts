
export type UserRole = 'member' | 'admin';
export type RSVPStatus = 'pendiente' | 'si' | 'no';

export interface User {
  id: string;
  name: string;
  email: string;
  teamId?: string;
  birthday?: string;
  avatar?: string;
  role?: UserRole;
}

export interface Team {
  id: string;
  name: string;
  inviteCode: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  text: string;
  timestamp: string;
}

export interface Invite {
  id: string;
  merendolaId: string;
  userId: string;
  status: RSVPStatus;
  respondedAt?: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'MERENDOLA_INVITE' | 'SYSTEM';
  payload: {
    merendolaId: string;
    title: string;
    date: string;
    creatorName: string;
  };
  readAt?: string;
  createdAt: string;
}

export interface Snack {
  id: string;
  userId: string;
  teamId: string;
  eventTitle: string;
  contribution: string;
  date: string;
  time: string;
  description?: string;
  userName?: string;
  confirmedUserIds: string[]; // Legacy - We will prioritize invites now
  comments: Comment[];
}

export interface AppState {
  user: User | null;
  team: Team | null;
  snacks: Snack[];
  teamMembers: User[];
  notifications: Notification[];
  invites: Invite[];
}
