
import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { UI_TEXT } from '../constants';
import { RSVPStatus } from '../types';

/**
 * Dashboard component with Monthly Calendar and Notification Center.
 */
const Dashboard: React.FC = () => {
  const { state, addSnack, deleteSnack, respondToInvite, markNotificationRead } = useStore();
  const [showModal, setShowModal] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [selectedSnackId, setSelectedSnackId] = useState<string | null>(null);
  
  // Calendar State
  const [viewDate, setViewDate] = useState(new Date());
  const [currentView, setCurrentView] = useState<'calendar' | 'list'>('calendar');

  const [newSnack, setNewSnack] = useState({
    eventTitle: '',
    contribution: '',
    date: new Date().toISOString().split('T')[0],
    time: '17:00',
    description: ''
  });

  const unreadNotifications = useMemo(() => 
    state.notifications.filter(n => !n.readAt).sort((a,b) => b.createdAt.localeCompare(a.createdAt)),
  [state.notifications]);

  // Calendar Logic
  const calendarData = useMemo(() => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    
    // First day of month (0=Sun, 1=Mon, ...)
    const firstDayDate = new Date(year, month, 1);
    const firstDayOfMonth = firstDayDate.getDay(); 
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // Adjust for Monday start (0=Mon, 1=Tue, ..., 6=Sun)
    const padding = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1;
    
    const days = [];
    // Padding for previous month
    for (let i = 0; i < padding; i++) {
      days.push({ day: null, date: null, snacks: [] });
    }
    // Days of current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
      const snacksOnDay = state.snacks.filter(s => s.date === dateStr);
      days.push({ day: i, date: dateStr, snacks: snacksOnDay });
    }
    
    return days;
  }, [viewDate, state.snacks]);

  const monthName = viewDate.toLocaleString('es-ES', { month: 'long', year: 'numeric' });

  const handleAddSnack = () => {
    if (!newSnack.eventTitle || !newSnack.contribution) return;
    addSnack(newSnack);
    setShowModal(false);
    setNewSnack({
      eventTitle: '',
      contribution: '',
      date: new Date().toISOString().split('T')[0],
      time: '17:00',
      description: ''
    });
  };

  const changeMonth = (offset: number) => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + offset, 1));
  };

  const getAttendeesByStatus = (snackId: string) => {
    const statuses: Record<RSVPStatus, any[]> = { si: [], no: [], pendiente: [] };
    
    state.teamMembers.forEach(member => {
      const invite = state.invites.find(i => i.merendolaId === snackId && i.userId === member.id);
      const status = invite ? invite.status : 'pendiente';
      statuses[status].push(member);
    });

    if (state.user) {
      const myInvite = state.invites.find(i => i.merendolaId === snackId && i.userId === state.user!.id);
      const myStatus = myInvite ? myInvite.status : 'pendiente';
      statuses[myStatus].push(state.user);
    }

    return statuses;
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark text-[#111827] dark:text-white">
      <header className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1a262f] px-6 md:px-10 py-3 sticky top-0 z-50 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="text-primary">
            <span className="material-symbols-outlined text-3xl">cookie</span>
          </div>
          <div>
            <h2 className="text-lg font-bold leading-tight">{UI_TEXT.APP_NAME}</h2>
            <p className="text-xs text-slate-500 font-medium">{state.team?.name}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-white/5 transition-colors relative"
            >
              <span className="material-symbols-outlined">notifications</span>
              {unreadNotifications.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-[#1a262f]">
                  {unreadNotifications.length}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-[#1a262f] rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                  <h4 className="font-bold text-sm">{UI_TEXT.DASHBOARD.NOTIFICATIONS.TITLE}</h4>
                  <button onClick={() => setShowNotifications(false)} className="text-slate-400 hover:text-slate-600">
                    <span className="material-symbols-outlined text-sm">close</span>
                  </button>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  {unreadNotifications.length === 0 ? (
                    <div className="p-8 text-center">
                      <p className="text-xs text-slate-400 font-medium">{UI_TEXT.DASHBOARD.NOTIFICATIONS.EMPTY}</p>
                    </div>
                  ) : (
                    unreadNotifications.map(n => (
                      <div key={n.id} className="p-4 hover:bg-slate-50 dark:hover:bg-white/5 border-b border-slate-50 dark:border-white/5 transition-colors">
                        <p className="text-xs font-bold text-primary mb-1">{n.payload.title}</p>
                        <p className="text-xs text-slate-600 dark:text-slate-400">
                          {UI_TEXT.DASHBOARD.NOTIFICATIONS.INVITE_MSG(n.payload.creatorName)}
                        </p>
                        <div className="flex gap-2 mt-3">
                          <button 
                            onClick={() => { respondToInvite(n.payload.merendolaId, 'si'); setShowNotifications(false); }}
                            className="bg-primary text-white text-[10px] font-bold px-3 py-1.5 rounded-lg shadow-sm"
                          >
                            {UI_TEXT.DASHBOARD.NOTIFICATIONS.ACCEPT}
                          </button>
                          <button 
                            onClick={() => respondToInvite(n.payload.merendolaId, 'no')}
                            className="bg-slate-100 dark:bg-white/10 text-[10px] font-bold px-3 py-1.5 rounded-lg"
                          >
                            {UI_TEXT.DASHBOARD.NOTIFICATIONS.REJECT}
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          <button 
            onClick={() => setShowModal(true)}
            className="bg-primary text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-primary/90 transition-all shadow-lg shadow-primary/20"
          >
            <span className="material-symbols-outlined text-sm">add</span>
            <span className="hidden xs:inline">{UI_TEXT.DASHBOARD.ADD_SNACK}</span>
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto w-full p-6 md:p-10">
        
        {/* View Selection & Calendar Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div className="flex items-center gap-4">
            <h3 className="text-2xl font-bold capitalize">{monthName}</h3>
            <div className="flex bg-white dark:bg-[#1a262f] rounded-lg border border-slate-200 dark:border-slate-800 p-1 shadow-sm">
              <button onClick={() => changeMonth(-1)} className="p-1 hover:bg-slate-100 dark:hover:bg-white/5 rounded-md transition-colors" aria-label="Mes anterior">
                <span className="material-symbols-outlined">chevron_left</span>
              </button>
              <button onClick={() => setViewDate(new Date())} className="px-2 text-[10px] font-black uppercase hover:bg-slate-100 dark:hover:bg-white/5 rounded-md transition-colors">Hoy</button>
              <button onClick={() => changeMonth(1)} className="p-1 hover:bg-slate-100 dark:hover:bg-white/5 rounded-md transition-colors" aria-label="Mes siguiente">
                <span className="material-symbols-outlined">chevron_right</span>
              </button>
            </div>
          </div>
          <div className="flex bg-white dark:bg-[#1a262f] rounded-lg border border-slate-200 dark:border-slate-800 p-1 shadow-sm">
             <button 
               onClick={() => setCurrentView('calendar')}
               className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${currentView === 'calendar' ? 'bg-primary text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}
             >
               Calendario
             </button>
             <button 
               onClick={() => setCurrentView('list')}
               className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${currentView === 'list' ? 'bg-primary text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}
             >
               Lista
             </button>
          </div>
        </div>

        {currentView === 'calendar' ? (
          <div className="bg-white dark:bg-[#1a262f] rounded-2xl shadow-xl border border-slate-100 dark:border-slate-800 overflow-hidden">
            <div className="grid grid-cols-7 border-b border-slate-100 dark:border-slate-800">
              {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map(day => (
                <div key={day} className="py-4 text-center text-[10px] font-black uppercase text-slate-400 tracking-wider">
                  {day}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7">
              {calendarData.map((item, idx) => (
                <div 
                  key={idx} 
                  className={`min-h-[120px] p-2 border-r border-b border-slate-50 dark:border-white/5 transition-colors ${!item.day ? 'bg-slate-50/50 dark:bg-black/10' : 'hover:bg-slate-50 dark:hover:bg-white/5'}`}
                >
                  {item.day && (
                    <>
                      <div className="flex justify-between items-start mb-2">
                        <span className={`text-sm font-bold ${item.date === new Date().toISOString().split('T')[0] ? 'bg-primary text-white w-6 h-6 rounded-full flex items-center justify-center' : 'text-slate-400'}`}>
                          {item.day}
                        </span>
                      </div>
                      <div className="flex flex-col gap-1">
                        {item.snacks?.map(snack => (
                          <button 
                            key={snack.id}
                            onClick={() => setSelectedSnackId(snack.id)}
                            className="text-[10px] font-bold bg-primary/10 text-primary p-1.5 rounded-lg text-left truncate border border-primary/20 hover:bg-primary/20 transition-all"
                          >
                            {snack.eventTitle}
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
             {state.snacks.length === 0 ? (
               <div className="bg-white dark:bg-[#1a262f] p-12 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                 <span className="material-symbols-outlined text-4xl text-slate-300 mb-4">event_busy</span>
                 <p className="text-slate-500 font-medium">{UI_TEXT.DASHBOARD.EMPTY_SNACKS}</p>
               </div>
             ) : (
               state.snacks.slice().sort((a,b) => a.date.localeCompare(b.date)).map(snack => (
                 <div key={snack.id} className="bg-white dark:bg-[#1a262f] p-4 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center justify-between shadow-sm hover:shadow-md transition-all">
                    <div className="flex items-center gap-4">
                       <div className="bg-primary/10 text-primary w-12 h-12 rounded-xl flex flex-col items-center justify-center font-bold">
                          <span className="text-xs uppercase">{new Date(snack.date).toLocaleString('es-ES', { month: 'short' })}</span>
                          <span className="text-lg leading-none">{new Date(snack.date).getDate()}</span>
                       </div>
                       <div>
                          <h4 className="font-bold text-base">{snack.eventTitle}</h4>
                          <p className="text-xs text-slate-500">{snack.time} • {snack.userName}</p>
                       </div>
                    </div>
                    <button onClick={() => setSelectedSnackId(snack.id)} className="text-primary text-sm font-bold hover:bg-primary/5 px-4 py-2 rounded-lg">Ver detalles</button>
                 </div>
               ))
             )}
          </div>
        )}
      </main>

      {/* Snack Details Modal */}
      {selectedSnackId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#1a262f] w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            {state.snacks.find(s => s.id === selectedSnackId) && (
              <>
                <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold">{state.snacks.find(s => s.id === selectedSnackId)?.eventTitle}</h3>
                    <p className="text-sm text-slate-500 mt-1 flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm">calendar_month</span>
                      {state.snacks.find(s => s.id === selectedSnackId)?.date} a las {state.snacks.find(s => s.id === selectedSnackId)?.time}
                    </p>
                  </div>
                  <button onClick={() => setSelectedSnackId(null)} className="p-2 hover:bg-slate-100 dark:hover:bg-white/5 rounded-full transition-colors text-slate-400">
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>
                <div className="p-6 max-h-[70vh] overflow-y-auto">
                   <div className="mb-6">
                      <h4 className="text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">{UI_TEXT.DASHBOARD.ATTENDEES.TITLE}</h4>
                      <div className="flex flex-wrap gap-4">
                         {Object.entries(getAttendeesByStatus(selectedSnackId)).map(([status, members]) => (
                            <div key={status} className="flex flex-col gap-2">
                               <p className="text-[10px] font-bold text-slate-400 capitalize">{status === 'si' ? 'Asisten' : status === 'no' ? 'No asisten' : 'Pendientes'}</p>
                               <div className="flex -space-x-2">
                                  {members.map(m => (
                                    <img key={m.id} src={m.avatar || `https://i.pravatar.cc/150?u=${m.id}`} className="w-8 h-8 rounded-full border-2 border-white dark:border-[#1a262f] object-cover" title={m.name} alt={m.name} />
                                  ))}
                                  {members.length === 0 && <span className="text-[10px] text-slate-300 italic">Nadie</span>}
                               </div>
                            </div>
                         ))}
                      </div>
                   </div>

                   <div className="bg-slate-50 dark:bg-white/5 p-4 rounded-2xl mb-6">
                      <p className="text-xs font-bold mb-1">Trae: <span className="text-primary">{state.snacks.find(s => s.id === selectedSnackId)?.contribution}</span></p>
                      <p className="text-xs text-slate-600 dark:text-slate-400">{state.snacks.find(s => s.id === selectedSnackId)?.description}</p>
                   </div>
                </div>
                <div className="p-6 bg-slate-50/50 dark:bg-black/10 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3">
                   {state.snacks.find(s => s.id === selectedSnackId)?.userId === state.user?.id && (
                     <button 
                       onClick={() => { deleteSnack(selectedSnackId); setSelectedSnackId(null); }}
                       className="text-red-500 text-sm font-bold px-4 py-2 hover:bg-red-50 rounded-lg transition-all"
                     >
                       {UI_TEXT.DASHBOARD.DELETE}
                     </button>
                   )}
                   <button onClick={() => setSelectedSnackId(null)} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-6 py-2 rounded-xl text-sm font-bold shadow-sm">Cerrar</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Add Snack Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#1a262f] w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <h3 className="text-xl font-bold">{UI_TEXT.DASHBOARD.ADD_SNACK}</h3>
              <button onClick={() => setShowModal(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-white/5 rounded-full transition-colors text-slate-400">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black uppercase text-slate-400">{UI_TEXT.DASHBOARD.EVENT_TITLE}</label>
                <input
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#101a22] h-12 px-4 font-medium outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                  value={newSnack.eventTitle}
                  onChange={(e) => setNewSnack({...newSnack, eventTitle: e.target.value})}
                  placeholder="Ej: Merienda de Viernes"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-black uppercase text-slate-400">{UI_TEXT.DASHBOARD.DATE}</label>
                  <input
                    type="date"
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#101a22] h-12 px-4 font-medium outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                    value={newSnack.date}
                    onChange={(e) => setNewSnack({...newSnack, date: e.target.value})}
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-black uppercase text-slate-400">{UI_TEXT.DASHBOARD.TIME}</label>
                  <input
                    type="time"
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#101a22] h-12 px-4 font-medium outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                    value={newSnack.time}
                    onChange={(e) => setNewSnack({...newSnack, time: e.target.value})}
                  />
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-black uppercase text-slate-400">{UI_TEXT.DASHBOARD.CONTRIBUTION}</label>
                <input
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#101a22] h-12 px-4 font-medium outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                  value={newSnack.contribution}
                  onChange={(e) => setNewSnack({...newSnack, contribution: e.target.value})}
                  placeholder="Ej: Empanada y refrescos"
                />
              </div>
            </div>
            <div className="p-6 bg-slate-50/50 dark:bg-black/10 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-3">
              <button 
                onClick={handleAddSnack}
                disabled={!newSnack.eventTitle || !newSnack.contribution}
                className="w-full bg-primary hover:bg-primary/90 text-white rounded-xl h-12 text-sm font-bold shadow-lg shadow-primary/20 transition-all disabled:opacity-50"
              >
                {UI_TEXT.DASHBOARD.SAVE}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
