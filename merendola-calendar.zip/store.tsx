
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, Team, Snack, AppState, Comment, Notification, Invite, RSVPStatus } from './types';

interface StoreContextType {
  state: AppState;
  login: (email: string) => void;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  setTeam: (team: Team) => void;
  addSnack: (snack: Omit<Snack, 'id' | 'userId' | 'teamId' | 'confirmedUserIds' | 'comments'>) => void;
  editSnack: (id: string, updates: Partial<Snack>) => void;
  deleteSnack: (id: string) => void;
  toggleAttendance: (snackId: string) => void;
  respondToInvite: (merendolaId: string, status: RSVPStatus) => void;
  markNotificationRead: (id: string) => void;
  addComment: (snackId: string, text: string) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const MOCK_TEAM_MEMBERS: User[] = [
  { id: 'u2', name: 'Laura Martínez', email: 'laura@empresa.es', birthday: '1995-05-12', avatar: 'https://i.pravatar.cc/150?u=laura' },
  { id: 'u3', name: 'Carlos Sanz', email: 'carlos@empresa.es', birthday: '1988-12-24', avatar: 'https://i.pravatar.cc/150?u=carlos' },
  { id: 'u4', name: 'Elena Peñas', email: 'elena@empresa.es', birthday: '1992-08-15', avatar: 'https://i.pravatar.cc/150?u=elena' },
];

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('merendola_state_v3');
    const initialState = saved ? JSON.parse(saved) : { 
      user: null, 
      team: null, 
      snacks: [], 
      teamMembers: MOCK_TEAM_MEMBERS,
      notifications: [],
      invites: []
    };
    return { ...initialState, teamMembers: MOCK_TEAM_MEMBERS };
  });

  useEffect(() => {
    localStorage.setItem('merendola_state_v3', JSON.stringify(state));
  }, [state]);

  const login = useCallback((email: string) => {
    const mockUser: User = {
      id: 'u1',
      name: 'Alex Rivera',
      email: email,
      avatar: `https://picsum.photos/seed/${email}/200/200`,
      role: 'admin'
    };
    
    // Simulate initial notifications for a new login if they don't exist
    const mockNotifications: Notification[] = [
      {
        id: 'n1',
        userId: 'u1',
        type: 'MERENDOLA_INVITE',
        payload: {
          merendolaId: 's1',
          title: 'Tarde de Donuts',
          date: '2024-12-20',
          creatorName: 'Laura Martínez'
        },
        createdAt: new Date().toISOString()
      }
    ];

    setState(prev => ({ 
      ...prev, 
      user: mockUser,
      notifications: prev.notifications.length ? prev.notifications : mockNotifications
    }));
  }, []);

  const logout = useCallback(() => {
    setState({ user: null, team: null, snacks: [], teamMembers: MOCK_TEAM_MEMBERS, notifications: [], invites: [] });
    localStorage.removeItem('merendola_state_v3');
  }, []);

  const updateUser = useCallback((updates: Partial<User>) => {
    setState(prev => ({
      ...prev,
      user: prev.user ? { ...prev.user, ...updates } : null
    }));
  }, []);

  const setTeam = useCallback((team: Team) => {
    setState(prev => ({
      ...prev,
      team,
      user: prev.user ? { ...prev.user, teamId: team.id } : null
    }));
  }, []);

  const addSnack = useCallback((snackData: Omit<Snack, 'id' | 'userId' | 'teamId' | 'confirmedUserIds' | 'comments'>) => {
    if (!state.user || !state.team) return;
    const newSnack: Snack = {
      ...snackData,
      id: Math.random().toString(36).substring(7),
      userId: state.user.id,
      teamId: state.team.id,
      userName: state.user.name,
      confirmedUserIds: [],
      comments: []
    };
    setState(prev => ({ ...prev, snacks: [...prev.snacks, newSnack] }));
  }, [state.user, state.team]);

  const editSnack = useCallback((id: string, updates: Partial<Snack>) => {
    setState(prev => ({
      ...prev,
      snacks: prev.snacks.map(s => s.id === id ? { ...s, ...updates } : s)
    }));
  }, []);

  const deleteSnack = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      snacks: prev.snacks.filter(s => s.id !== id)
    }));
  }, []);

  const toggleAttendance = useCallback((snackId: string) => {
    if (!state.user) return;
    const userId = state.user.id;
    setState(prev => ({
      ...prev,
      snacks: prev.snacks.map(s => {
        if (s.id !== snackId) return s;
        const exists = s.confirmedUserIds.includes(userId);
        return {
          ...s,
          confirmedUserIds: exists 
            ? s.confirmedUserIds.filter(id => id !== userId)
            : [...s.confirmedUserIds, userId]
        };
      })
    }));
  }, [state.user]);

  const respondToInvite = useCallback((merendolaId: string, status: RSVPStatus) => {
    if (!state.user) return;
    const inviteId = `inv_${merendolaId}_${state.user.id}`;
    
    setState(prev => {
      const existingInviteIndex = prev.invites.findIndex(i => i.merendolaId === merendolaId && i.userId === state.user!.id);
      let newInvites = [...prev.invites];
      
      const inviteData: Invite = {
        id: inviteId,
        merendolaId,
        userId: state.user!.id,
        status,
        respondedAt: new Date().toISOString()
      };

      if (existingInviteIndex >= 0) {
        newInvites[existingInviteIndex] = inviteData;
      } else {
        newInvites.push(inviteData);
      }

      // Also mark associated notifications as read
      const newNotifications = prev.notifications.map(n => 
        n.payload.merendolaId === merendolaId ? { ...n, readAt: new Date().toISOString() } : n
      );

      return { ...prev, invites: newInvites, notifications: newNotifications };
    });
  }, [state.user]);

  const markNotificationRead = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      notifications: prev.notifications.map(n => n.id === id ? { ...n, readAt: new Date().toISOString() } : n)
    }));
  }, []);

  const addComment = useCallback((snackId: string, text: string) => {
    if (!state.user) return;
    const newComment: Comment = {
      id: Math.random().toString(36).substring(7),
      userId: state.user.id,
      userName: state.user.name || 'Usuario',
      text,
      timestamp: new Date().toISOString()
    };
    setState(prev => ({
      ...prev,
      snacks: prev.snacks.map(s => s.id === snackId ? { ...s, comments: [...s.comments, newComment] } : s)
    }));
  }, [state.user]);

  return (
    <StoreContext.Provider value={{
      state, login, logout, updateUser, setTeam, addSnack, editSnack, deleteSnack, toggleAttendance, respondToInvite, markNotificationRead, addComment
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within StoreProvider');
  return context;
};
